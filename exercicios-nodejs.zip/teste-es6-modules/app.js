import { cumprimentar, calcularIdade, PI } from './utils.js';

import despedir from './utils.js';

console.log('=== TESTANDO ES6 MODULES ===');

console.log(cumprimentar('Maria'));
console.log('Idade:', calcularIdade(1990));
console.log('Valor de PI:', PI);

console.log(despedir('Maria'));

console.log('=== TESTE CONCLUÍDO ===');