// LINHA 1: importa nossa classe logger do arquivo logger.js
// O './' significa "na mesma pasta que este arquivo"
const Logger = require('./logger');

// LINHA 2: Função que vai testar nosso logger
// 'async' significa que esta função pode "esperar" outras operações
async function testarLogger() {
    console.log('🚀Iniciando teste do Logger...');

    // LINHA 3: Cria um novo logger que vai salvar no arquivo 'teste.log'
    const logger = new Logger('teste.log');

    //LINHA 4: testa diferentes tipos de mensagem
    await logger.info('Aplicação iniciada com sucesso!');
    await logger.warn('Esta é uma mensagem de aviso');
    await logger.error('Simulando um erro de teste');

    console.log('✅ Teste concluido! verifique o arquivo teste.log');
}

// LINHA 5: Executa nossa função de teste
testarLogger();