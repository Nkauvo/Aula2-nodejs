// 1. IMPORTAÇÕES - Trazendo as ferramentas que vamos usar
const fs = require('fs').promises;
const path = require('path');

// 2. CLASSE LOGGER - Nossa "fabrica" de logs
class Logger {
    // CONSTRUTOR - Executa quando criamos um novo logger
    constructor(logFile = 'app.log') {
        // __dirname = pasta atual do arquivo
        // path.join = junta caminhos de forma segura
        this.logFile = path.join(__dirname, logFile);
        console.log(`📝 Logger criado! Arquivo: ${this.logFile}`);
    }

    // MÉTODO PRINCIPAL - escreve qualquer tipo de log
    async log(message, level = 'INFO') {
        //cria um "carimbo de data e hora" (tipo: 2024-01-15 às 10:30:45)
        const timestamp = new Date().toISOString();

        //Monta a linha log: [data] nivel: mensagem
        const logEntry = `[${timestamp}] ${level}: ${message}\n`;

        try {
            await fs.appendFile(this.logFile, logEntry);
            console.log(`✅ Log salvo: ${level} - ${message}`);
        } catch (error) {
            console.error('❌ Erro ao escrever log:', error.message)
        }
    }

    // MÉTODO DE CONVENIÊNCIA - Para logs informativos
    async info(message) {
        await this.log(message, 'INFO');
    }

    // MÉTODO DE CONVENIÊNCIA - Para logs de erro
    async error(message) {
        await this.log(message, 'ERROR');
    }

    //MÉTODO EXTRA - Para logs de aviso
    async warn(message) {
        await this.log(message, 'WARN');
    }
}

//EXPORTA a classe para outros arquivos usarem
module.exports = Logger;