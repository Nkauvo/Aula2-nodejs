// Função para somar dois números
function somar(a, b) {
    console.log(`Somando ${a} + ${b}`);
    return a + b;
}

// Função para multiplicar dois números
function multiplicar(a, b){
    console.log(`Multiplicando ${a} * ${b}`);
    return a * b;
}

//Função para dividir dois números
function dividir(a, b) {
    if (b === 0) {
        console.log('Erro: não é possivel dividir por zero!');
        return null;
    }
    console.log(`Dividindo ${a} / ${b}`);
    return a / b;
}

//IMPORTANTE: Exportando as funções para outros arquivos poderem usar
module.exports = {
    somar,
    multiplicar,
    dividir
};